package com.example.complaintapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView signup;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        signup = (TextView) findViewById(R.id.l_sign_up);
        signup.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v1) {
                openSignUp();
            }
        });
//        Log.d("MainActivity","Inside oncreate method");
//        Log.i("MainActivity","Inside oncreate method");
//        Log.e("MainActivity","Inside oncreate method");
    }
    private void openSignUp(){
        Intent intent= new Intent(getApplicationContext(),SignUp.class);
        startActivity(intent);
    }
}